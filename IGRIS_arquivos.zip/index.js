// IGRIS - Etapa 1: diagnostico seguro do grupo (somente leitura).
// Criador: Espadachim RTX
// Este arquivo NAO promove, rebaixa ou atribui cargos.

const API_KEY = process.env.ROBLOX_API_KEY;
const GROUP_ID = process.env.ROBLOX_GROUP_ID;

if (!API_KEY || !/^\d+$/.test(GROUP_ID || "")) {
  console.error("IGRIS: configure ROBLOX_API_KEY e ROBLOX_GROUP_ID no Railway.");
  process.exit(1);
}

const BASE = `https://apis.roblox.com/cloud/v2/groups/${GROUP_ID}`;

async function getRoblox(endpoint) {
  const response = await fetch(`${BASE}${endpoint}`, {
    headers: { "x-api-key": API_KEY, "Accept": "application/json" },
    signal: AbortSignal.timeout(15000)
  });
  if (!response.ok) {
    throw new Error(`Roblox HTTP ${response.status} ao consultar ${endpoint.split('?')[0]}`);
  }
  return response.json();
}

async function conferirGrupo() {
  try {
    const rolesResult = await getRoblox("/roles?maxPageSize=100");
    const membershipsResult = await getRoblox("/memberships?maxPageSize=10");
    const roles = rolesResult.groupRoles;
    const memberships = membershipsResult.groupMemberships;

    if (!Array.isArray(roles) || !Array.isArray(memberships)) {
      throw new Error("Formato da resposta inesperado. Nenhuma alteracao sera feita.");
    }

    console.log("IGRIS: conexao com Roblox OK!");
    console.log(`IGRIS: grupo ${GROUP_ID}. Cargos consultados: ${roles.length}.`);
    console.log(`IGRIS: primeiro lote de membros consultado: ${memberships.length}.`);
    console.log("IGRIS: cargos encontrados:", roles.map(r => r.displayName || r.name || r.path).join(" | "));
    console.log("IGRIS: MODO SEGURO ATIVO (nenhum cargo foi modificado).");
  } catch (error) {
    console.error("IGRIS: falha na consulta:", error.message);
  }
}

await conferirGrupo();
setInterval(conferirGrupo, 10 * 60 * 1000);
